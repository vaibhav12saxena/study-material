
module All {
export class IProduct {
    
    productId:number;
    productName:string;
}
}