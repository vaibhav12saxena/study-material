//2 parameter with number as return type
function getsum(numOne, numTwo) {
    return numOne + numTwo;
}
var add = getsum(10, 6);
document.write("Sum is " + add + " <br/>");
//any number of data--know as rest parameter 
function sumAll() {
    var num = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        num[_i] = arguments[_i];
    }
    var sum = 0;
    for (var _a = 0, num_1 = num; _a < num_1.length; _a++) {
        var data = num_1[_a];
        sum = sum + data;
        document.write("Addition of number " + data + "<br/>");
    }
    document.write("Sum is " + sum + "<br/>");
}
sumAll(6, 7, 8, 9);
//Optional parameter----? for optional & Default parameter
function doGet(one, two, three) {
    if (two === void 0) { two = 5; }
    //alert("hii");
    document.write(one.toString());
    document.write(two.toString());
    document.write(three.toString());
}
//doGet(10);
doGet(10);
